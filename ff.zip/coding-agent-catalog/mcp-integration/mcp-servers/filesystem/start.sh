#!/bin/sh
exec npx @modelcontextprotocol/server-filesystem /workspace