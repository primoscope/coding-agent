#!/usr/bin/env bash
set -euo pipefail

echo "No long-running daemon to stop. MCP servers are launched on-demand by the client."