#!/bin/sh
export PUPPETEER_EXECUTABLE_PATH=/usr/bin/chromium-browser
exec npx @modelcontextprotocol/server-puppeteer